Visual C++ 2015 redistributable is required.

Use "./Elko" to launch the program or double-click.

